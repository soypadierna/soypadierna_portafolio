// ============================================================
// CÓMO AGREGAR UN PROYECTO NUEVO
// ------------------------------------------------------------
// Copia el bloque de ejemplo de abajo, pégalo dentro del
// arreglo `proyectos` (más abajo) y rellena los datos.
// No necesitas imagen ni tocar ningún otro archivo.
//
// {
//   curso: "ISW-304",      // código del curso (deja "" si no aplica)
//   semestre: "2026-1",    // deja "" si no aplica
//   titulo: "Nombre del proyecto",
//   descripcion: "Una o dos frases: qué hiciste y qué resolvió.",
//   stack: ["Java", "MySQL"],   // tecnologías, alimentan los filtros
//   enlace: "https://github.com/tu-usuario/repo",  // repo, demo o PDF
//   imagen: "imagenes/mi-proyecto.png"  // opcional, o "" si no hay
// },
// ============================================================

const proyectos = [
  {
    curso: "ISW-304",
    semestre: "2025-2",
    titulo: "Sistema de Facturación",
    descripcion: "Aplicación de escritorio con login, CRUDs de clientes y productos, y generación de facturas.",
    stack: ["Java", "MySQL"],
    enlace: "#"
  },
  {
    curso: "",
    semestre: "2026-1",
    titulo: "Padierna — Rastreo de guías",
    descripcion: "App Android para consultar el estado de guías de envío de Servientrega.",
    stack: ["Kotlin", "Android"],
    enlace: "#"
  }
];
